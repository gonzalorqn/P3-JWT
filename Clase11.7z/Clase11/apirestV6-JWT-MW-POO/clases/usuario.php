<?php
class usuario
{
    public $id;
 	public $nombre;
  	public $clave;
    public $perfil;
      
    public static function TraerUnUsuario($nombre, $clave) 
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE nombre = $nombre && clave = $clave");
		$consulta->execute();
		$buscado= $consulta->fetchObject('usuario');
		return $buscado;
	}
}