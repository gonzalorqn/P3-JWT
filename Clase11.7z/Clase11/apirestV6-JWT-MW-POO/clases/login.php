<?php

require_once 'usuario.php';
require_once 'IApiUsable.php';

class login 
{
    public function hacerLogin($request, $response, $args)
    {
        $objRespuesta = new stdClass();
        $ArrayDeParametros = $request->getParsedBody();
        $nombre = $ArrayDeParametros['nombre'];
        $clave = $ArrayDeParametros['clave'];
        $miUsuario = usuario::TraerUnUsuario($nombre,$clave);

        $datos = array('usuario' => $miUsuario->nombre,'perfil' => $miUsuario->perfil);

        $token= AutentificadorJWT::CrearToken($datos); 
     	 $response->withStatus(200)
            ->withHeader('Content-Type', 'text/html')
            ->write("{token:$token}");
    }
}