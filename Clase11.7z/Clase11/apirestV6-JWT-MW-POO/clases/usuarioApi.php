<?php
require_once 'usuario.php';
require_once 'IApiUsable.php';
class usuarioApi extends usuario implements IApiUsable
{
 
      public function TraerUnUsuario($request, $response, $args) {
     	
        $objDelaRespuesta= new stdclass();
        
        $ArrayDeParametros = $request->getParsedBody();
        $nombre= $ArrayDeParametros['nombre'];
        $clave= $ArrayDeParametros['clave'];
        $miUsuario = TraerUnUsuario( $clave, $nombre);
     
        return  $miUsuario 
    }